# Balanced Synchrony in Coupled Network Systems

**Research code · Graph theory · Network automorphisms · Scientific Python**

This repository refactors two research notebooks developed as part of my master's research in Mathematics at the University of São Paulo (USP). It studies **balanced equivalence relations** (which describe robust synchrony subspaces) and identifies **exotic synchrony patterns** on directed networks with one or multiple types of edges.

The broader master's project concerns stability bifurcations of synchrony patterns in Laplacian-coupled dynamical systems. **This repository addresses the complementary problem of identifying balanced synchrony partitions using graph combinatorics and symmetry; it does not implement the Laplacian stability calculations or machine-learning models.**

## What this project does

- Enumerates all set partitions of a network's vertices (Bell-number complexity).
- Identifies balanced partitions using input counts from each source block to each target block, separately for each edge type.
- Computes **direction-, type- and multiplicity-preserving automorphisms** with NetworkX.
- Removes symmetry-equivalent solutions using canonical partition representatives.
- Classifies balanced partitions as **exotic** when they cannot be realized as the orbit partition of a subgroup of graph automorphisms.
- Displays the networks with partition-colored vertices and edge-type-dependent line colors.

## Preview

| Single edge type: Petersen network | Multiple edge types: six-vertex network |
| --- | --- |
| ![Balanced partition in the Petersen network](assets/petersen_balanced.png) | ![Two-edge-type balanced partition](assets/two_edge_types_balanced.png) |

The Frucht-graph example below verifies that exotic balanced partitions are also detected:

![Exotic balanced partition in the Frucht graph](assets/frucht_exotic.png)

## Mathematical formulation

Let \(A^{(c)}_{uv}\) be the number of edges of type \(c\) pointing **from** vertex \(u\) **to** vertex \(v\). A partition \(\mathcal{P}\) is balanced when, for every pair of blocks \(B,C\in\mathcal{P}\), every edge type \(c\), and any \(v,w\in B\),

\[
\sum_{u\in C} A^{(c)}_{uv} = \sum_{u\in C} A^{(c)}_{uw}.
\]

A balanced partition is *not exotic* if it is the orbit partition of some subgroup of the automorphism group preserving all edge types. The algorithm uses the subgroup of automorphisms preserving every block setwise: its orbits coincide with the partition if and only if a realizing subgroup exists.

> **Scope:** adjacency entries are nonnegative integers (directed edge multiplicities), not arbitrary real coupling weights. The graph algorithms are exact but exhaustive; they are intended for small networks.

## Examples and regression results

| Example | Vertices | Automorphisms | Examined partitions | Balanced representatives (up to symmetry) | Exotic representatives |
| --- | ---: | ---: | ---: | ---: | ---: |
| Relabeled Petersen graph (one edge type) | 10 | 120 | 115,975 | 11 | 0 |
| Six-vertex graph (two edge types) | 6 | 8 | 203 | 5 | 0 |

The notebooks recreate both original examples. The **Frucht graph** (12 vertices, degree three, trivial automorphism group) is used as a separate, computationally inexpensive positive example of exotic synchrony: its one-block partition is balanced, but is not induced by graph symmetries.

## Install and run

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e '.[dev]'
python -m pytest -q
jupyter lab
```

Open either notebook in `notebooks/`:

- [`single_edge_type.ipynb`](notebooks/single_edge_type.ipynb) — Petersen example and a separate exotic Frucht example.
- [`multiple_edge_types.ipynb`](notebooks/multiple_edge_types.ipynb) — two edge types, type-preserving graph symmetries and balanced partitions.

Alternatively, use the reusable Python API:

```python
from balanced_synchrony import search_balanced_partitions
from balanced_synchrony.examples import two_edge_types_network

result = search_balanced_partitions(two_edge_types_network())
print(result.examined, result.balanced_count, result.exotic_count)
# 203 5 0
```

## Code structure

```text
src/balanced_synchrony/   Reusable analysis, graph examples, plotting
notebooks/                 Two clean executable research notebooks
tests/                     Mathematical regression and edge-color tests
.github/workflows/         GitHub Actions test workflow
```

## Design choices and limitations

- **Correct multigraph matching:** `categorical_multiedge_match` compares the full edge-type multiset for parallel edges. Using the ordinary single-edge matcher can accidentally ignore type constraints.
- **No duplicate source implementations:** both notebooks import the same tested functions.
- **Outputs are not committed:** large saved notebook plots are replaced with cells that run reproducibly.
- **Exhaustive search:** the number of partitions is the Bell number \(B_n\), making large graphs expensive. The Frucht example therefore checks one targeted partition rather than enumerating \(B_{12}\) partitions.
- **Research boundary:** the program identifies synchrony relations, not their nonlinear dynamics, spectral stability, or neural-network performance.

## Research context

Developed by **Marcelo da Silveira Salazar Filho**, M.Sc. Mathematics researcher, University of São Paulo (USP). This is a cleaned research-code demonstration; conclusions depend on the modeled network and the definitions given above.
