# Publishing this project on GitHub

This folder is already organized as a repository and includes a CI workflow. To publish it:

1. Sign in at <https://github.com/new>.
2. Create an **empty public repository** named `balanced-synchrony-networks` (don't initialize a README or `.gitignore`; both are included here).
3. From a terminal inside the extracted project folder, run:

```bash
git init
git add .
git commit -m "Add tested balanced synchrony research project"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/balanced-synchrony-networks.git
git push -u origin main
```

Replace `YOUR_GITHUB_USERNAME` with your GitHub username. GitHub may ask you to authenticate, for example through Git Credential Manager. Do not share GitHub passwords or personal access tokens in chats or files.

For a job application, copy the **repository URL** (not a link to a downloaded ZIP). Once the repository is public, optionally pin it to your GitHub profile and add the direct repository link to your CV.

If you prefer assistance uploading, create the empty repository and share only its URL; the files in this package can then be added through the connected GitHub integration.
