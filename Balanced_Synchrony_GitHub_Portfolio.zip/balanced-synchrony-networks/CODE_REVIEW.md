# Research code review and refactoring notes

This project is based on two submitted notebooks. The graph definitions and mathematical classification are retained, but the implementation is refactored for testability and clear public presentation.

## Issues corrected

1. **Incorrect edge-type matching in the multigraph notebook.** `MultiDiGraphMatcher` must receive `categorical_multiedge_match` rather than `categorical_edge_match`; the latter can ignore edge colors stored inside the nested edge-data mapping. A colored triangle regression test reproduces the distinction (6 uncolored automorphisms versus 2 color-preserving ones).
2. **Repeated logic in both notebooks.** Partition generation, balance checks, symmetry reduction, and exoticness detection are implemented once in `src/balanced_synchrony/analysis.py`.
3. **Unvalidated inputs and limited error reporting.** Adjacency matrices must have a consistent nonempty square shape and nonnegative integer entries; partitions must contain every vertex exactly once. Unbalanced partitions raise a clear error if passed to the exoticness classifier.
4. **Large saved outputs and blocking visualization.** Notebook outputs were removed. Graph plotting is separated from search and is only requested for selected partitions, rather than showing a window for every result.
5. **Mixed-language and excessive commentary.** Code is now in English, with concise explanations for the mathematical conventions and nonobvious implementation decisions.
6. **Reproducibility and checks.** Examples were extracted into deterministic functions; unit and regression tests check the original enumeration results and the presence of an exotic positive example.

## Results verified

| Example | Original intended result | Refactored result |
| --- | --- | --- |
| Relabeled Petersen graph | 115,975 partitions; 11 symmetry-distinct balanced relations; 0 exotic | Same |
| Six-node, two-color graph | 203 partitions; 5 symmetry-distinct balanced relations; 0 exotic | Same |
| Frucht graph (new targeted check) | Not active in the original example | One-block partition is balanced and exotic |

The corrected matcher makes a material difference for some colored graphs, even though the particular six-vertex example has the same automorphism count before and after the fix.

## Scope and limitations

- Adjacency entries are **edge multiplicities**, not general weighted Laplacian couplings.
- The search is exhaustive in the Bell number of nodes; it is not designed for large graph datasets.
- The classifier uses the standard group-orbit definition of *exotic* synchrony; it does not determine dynamical stability.
- Unit tests verify the examples and key edge cases, but they are not a formal proof of correctness for every possible network.
